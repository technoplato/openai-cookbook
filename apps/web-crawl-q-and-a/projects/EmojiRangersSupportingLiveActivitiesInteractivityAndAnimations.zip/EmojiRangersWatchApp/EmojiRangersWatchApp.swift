/*
See the LICENSE.txt file for this sample’s licensing information.

Abstract:
The watchOS app.
*/

import SwiftUI

@main
struct EmojiRangersWatchAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
