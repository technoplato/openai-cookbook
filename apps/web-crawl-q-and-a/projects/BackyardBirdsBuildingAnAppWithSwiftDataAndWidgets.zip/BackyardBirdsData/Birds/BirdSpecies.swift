/*
See the LICENSE.txt file for this sample’s licensing information.

Abstract:
The bird species.
*/

import Observation
import Foundation
import SwiftData

@Model public class BirdSpecies {
    @Attribute(.unique) public var id: String
    public var naturalScale: Double = 1
    public var isEarlyAccess: Bool
    public var parts: [BirdPart]
    
    @Relationship(.cascade, inverse: \Bird.species)
    public var birds: [Bird]
    
    public var info: BirdSpeciesInfo { BirdSpeciesInfo(rawValue: id) }
    
    public init(info: BirdSpeciesInfo, naturalScale: Double = 1, isEarlyAccess: Bool = false, parts: [BirdPart]) {
        self.id = info.rawValue
        self.naturalScale = naturalScale
        self.isEarlyAccess = isEarlyAccess
        self.parts = parts
    }
}
