/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The plant commands.
*/

import SwiftUI

struct PlantCommands: Commands {
    var body: some Commands {
        EmptyCommands()
    }
}

