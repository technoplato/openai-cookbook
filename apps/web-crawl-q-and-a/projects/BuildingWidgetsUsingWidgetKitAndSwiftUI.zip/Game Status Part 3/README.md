# Emoji Rangers: Part 3

Extend a widget by providing dynamic user-configurable properties, making background network requests, and supporting multiple widgets.

## Overview

- Note: This sample code project is associated with WWDC20 session [10036: Widgets Code-along, part 3: Advancing timelines](https://developer.apple.com/wwdc20/10036/).
